import React, { Component } from 'react';
//import './login.css';
var loginvalues = require("./login.json");

class Login extends Component {
   constructor(props) {
      super(props);

      this.state = {
         username: '',
         password: ''
      };

      this.usernameChange = this.usernameChange.bind(this);
      this.passwordChange = this.passwordChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
   }
   usernameChange(event) {
      this.setState({ username: event.target.value });
   }
   passwordChange(event) {
      this.setState({ password: event.target.value });
   }

   handleSubmit(event) {
      // alert('Username: ' + this.state.username + ','+'Password:'  + this.state.password);
      // event.preventDefault();
      if (loginvalues[this.state.username] != undefined) {
         if (loginvalues[this.state.username] == this.state.password) {
            this.props.history.push(`/dashboard`);
         }
      }
      else {
         alert("oops!! user is not found please contact siddarath Abimenyu...");
         this.setState({ "username": "", "password": "" });
         document.getElementsByName("username")[0].value = "";
         document.getElementsByName("password")[0].value = "";
         event.preventDefault();
      }
   }
   render() {
      return (

         <div className="col-md-12">
            <div className="col-md-4">
               <img className="logo" src="./../images/mainlogo.png"></img>
            </div>
            <div className="col-md-4">
               <h2 className="head">Login Form</h2>
               <form name="form" className="formlogin" onSubmit={this.handleSubmit}>
                  <div >

                     <label htmlFor="username">Username</label>
                     <input type="text" className="form-control" name="username" onChange={this.usernameChange} required />
                  </div><br></br>
                  <div >
                     <label htmlFor="password">Password</label>
                     <input type="password" className="form-control" name="password" onChange={this.passwordChange} required />
                  </div>

                  <div className="form-action-area">
            
                        <input className="button" type="submit" value="Submit" />
           
                  </div>

               </form>
            </div>
            <div className="col-md-4">

            </div>
         </div>
      );
   }
}


export default Login;