import React from 'react';
var system = require('./data.json');


export class Cisco_1 extends React.Component {
  constructor(props) {
    super(props);
    {
      this.state = { showing: true };
    
    }
  }
  changeButtonStatus(event) {
    var elem = event.target.parentElement.childNodes[1].firstChild;
    elem.classList.toggle("toggleDisplay");
  }
  render() {
    const { showing } = this.state;
    return (<div className="container-fluid box ">
      <div className="row">
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[1].operating.map((val, i) => {
                return <li className="fontcolor" key={i}><i className="fa fa-star star" aria-hidden="true"></i>&nbsp;{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[2].version.map((val, i) => {
                return <li key={i} className="liversion"><span className="version">Version :</span>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-3 btn_align1">
          {
            system[3].assign.map((val, i) => {
              // return <div className="mani"><button className="assign" value={i} key={i} onClick={() => this.setState({ showing: !showing })}>{val}</button>
              return <div className="mani"><button className="assign" value={i} key={i} onClick={this.changeButtonStatus.bind(this)}>{val}</button>
                <div className="col-md-12">
                  <div className="hidden drop">
                  <button className="btn btn-default">All</button>
                  <button className="btn btn-default">Core</button>
                  <button className="btn btn-default">Distribution</button>
                  <button className="btn btn-default">Border Router</button>
                  <button className="btn btn-default">Access</button>
                  <button className="btn btn-default">Unknown</button>
                  </div>
                </div>
              </div>;
            })

          }

        </div>
        <div className="col-md-1 btn_align2">
          {
            system[4].icon.map((val, i) => {
              return <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
            })
          }

        </div>

      </div>

    </div>);
  }
}

export class Cisco_2 extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (<div className="container-fluid box ">
      <div className="row">
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[1].operating.map((val, i) => {
                return <li className="fontcolor" key={i}><i className="fa fa-star star" aria-hidden="true"></i>&nbsp;{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[2].version.map((val, i) => {
                return <li key={i} className="liversion"><span className="version">Version :</span>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-3 btn_align1">
          {
            system[3].assign.map((val, i) => {
              return <button className="assign" key={i}>{val}</button>;
            })
          }


        </div>
        <div className="col-md-1 btn_align2">
          {
            system[4].icon.map((val, i) => {
              return <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
            })
          }

        </div>

      </div>
    </div>);
  }
}


export class Cisco_3 extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (<div className="container-fluid box ">
      <div className="row">
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[1].operating.map((val, i) => {
                return <li className="fontcolor" key={i}><i className="fa fa-star star" aria-hidden="true"></i>&nbsp;{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[2].version.map((val, i) => {
                return <li key={i} className="liversion"><span className="version">Version :</span>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-3 btn_align1">
          {
            system[3].assign.map((val, i) => {
              return <button className=" assign" key={i}>{val}</button>;
            })
          }


        </div>
        <div className="col-md-1 btn_align2">
          {
            system[4].icon.map((val, i) => {
              return <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
            })
          }

        </div>

      </div>
    </div>);
  }
}

export class Cisco_4 extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (<div className="container-fluid box ">
      <div className="row">
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[1].operating.map((val, i) => {
                return <li className="fontcolor" key={i}><i className="fa fa-star star" aria-hidden="true"></i>&nbsp;{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[2].version.map((val, i) => {
                return <li key={i} className="liversion"><span className="version">Version :</span>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-3 btn_align1">
          {
            system[3].assign.map((val, i) => {
              return <button className=" assign" key={i} >{val}</button>;
            })
          }


        </div>
        <div className="col-md-1 btn_align2">
          {
            system[4].icon.map((val, i) => {
              return <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
            })
          }

        </div>

      </div>
    </div>);
  }
}

