import React from 'react';
var system = require('./data.json');


export class Cisco_1 extends React.Component {
  constructor(props) {
    super(props);

  }
  changeButtonStatus(event) {
    var elem = event.target.parentElement.childNodes[2].firstChild;
    elem.classList.toggle("toggleDisplay");
  }
  appendcontent(event) {

    //console.log(event.target.value);
    var elemVal = parseInt(event.target.parentElement.parentElement.parentElement.getAttribute("value"));
    var all = event.target.value;
    var p = document.getElementsByClassName("buttonval");
    //console.log(p);
    for (var i = 0; i < p.length; i++) {
      if (parseInt(p[i].getAttribute('value')) == elemVal) {
        p[i].classList.add("para");
        var x = document.createTextNode(all);
        //  p[i].appendChild(x);
        if (p[i].innerText == "") {
          p[i].appendChild(x)
        } else {
          p[i].innerText = all;
        }
        this.displayTickIcon(i);
      }
    };
    var elemList = document.getElementsByClassName('btn inner');
    for (var i = 0; i < elemList.length; i++) {
      if (elemList[i].value == all) {
        elemList[i].style.display = "none";
      }
    };
  }
  displayTickIcon(iter) {
    var iconElemList = document.getElementsByClassName("tick");
    for (var i = 0; i < iconElemList.length; i++) {
      if (parseInt(iconElemList[i].getAttribute('value')) == iter) {
        iconElemList[i].style.display = "inline";
      }
    };
  }
  color(event) {
    var colorvalue = event.target.getAttribute('value');
    // console.log(colorvalue);
    var iconcolor = document.getElementsByClassName("star");
    for (var i = 0; i < iconcolor.length; i++) {
      if (parseInt(iconcolor[i].getAttribute('value')) == colorvalue) {
        iconcolor[i].classList.toggle("yellowcolor");
      }
    };
  }
  render() {

    return (<div className="container-fluid box ">
      <div className="row">
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[1].operating.map((val, i) => {
                return <div> <li className="fontcolor" key={i}><i value={i} className="fa fa-star star" aria-hidden="true" onClick={this.color.bind(this)}></i>&nbsp;{val}</li><p className="buttonval" value={i}></p></div>
              })
            }
          </ul>
        </div>
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[2].version.map((val, i) => {
                return <li key={i} className="liversion"><span className="version">Version :</span>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-3 btn_align1">
          {
            system[3].assign.map((val, i) => {
              // return <div className="mani"><button className="assign" value={i} key={i} onClick={() => this.setState({ showing: !showing })}>{val}</button>
              return <div className="mani" value={i}><img value={i} src="./../images/tick.png" className="tick"></img><button className="assign" value={i} key={i} onClick={this.changeButtonStatus.bind(this)}>{val}</button>
                <div className="col-md-12">
                  <div className="hidden drop">
                    <button className="btn inner" value="All" onClick={this.appendcontent.bind(this)}>All</button>&nbsp;&nbsp;
                  <button className="btn inner" value="Core" onClick={this.appendcontent.bind(this)}>Core</button>&nbsp;&nbsp;
                  <button className="btn inner" value="Distribution" onClick={this.appendcontent.bind(this)}>Distribution</button>&nbsp;&nbsp;
                  <button className="btn inner" value="Border Router" onClick={this.appendcontent.bind(this)}>Border Router</button>&nbsp;&nbsp;
                  <button className="btn inner" value="Access" onClick={this.appendcontent.bind(this)}>Access</button>&nbsp;&nbsp;
                  <button className="btn inner" value="Unknown" onClick={this.appendcontent.bind(this)}>Unknown</button>&nbsp;&nbsp;
                  <button className="btn inner" value="Card" onClick={this.appendcontent.bind(this)}>Card</button>
                  </div>
                </div>
              </div>;
            })

          }

        </div>
        <div className="col-md-1 btn_align2">
          {
            system[4].icon.map((val, i) => {
              return <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
            })
          }

        </div>

      </div>

    </div>);
  }
}

export class Cisco_2 extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (<div className="container-fluid box ">
      <div className="row">
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[1].operating.map((val, i) => {
                return <li className="fontcolor" key={i}><i className="fa fa-star star" aria-hidden="true"></i>&nbsp;{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[2].version.map((val, i) => {
                return <li key={i} className="liversion"><span className="version">Version :</span>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-3 btn_align1">
          {
            system[3].assign.map((val, i) => {
              return <button className="assign" key={i}>{val}</button>;
            })
          }


        </div>
        <div className="col-md-1 btn_align2">
          {
            system[4].icon.map((val, i) => {
              return <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
            })
          }

        </div>

      </div>
    </div>);
  }
}


export class Cisco_3 extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (<div className="container-fluid box ">
      <div className="row">
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[1].operating.map((val, i) => {
                return <li className="fontcolor" key={i}><i className="fa fa-star star" aria-hidden="true"></i>&nbsp;{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[2].version.map((val, i) => {
                return <li key={i} className="liversion"><span className="version">Version :</span>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-3 btn_align1">
          {
            system[3].assign.map((val, i) => {
              return <button className=" assign" key={i}>{val}</button>;
            })
          }


        </div>
        <div className="col-md-1 btn_align2">
          {
            system[4].icon.map((val, i) => {
              return <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
            })
          }

        </div>

      </div>
    </div>);
  }
}

export class Cisco_4 extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (<div className="container-fluid box ">
      <div className="row">
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[1].operating.map((val, i) => {
                return <li className="fontcolor" key={i}><i className="fa fa-star star" aria-hidden="true"></i>&nbsp;{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-4">
          <ul className="starpadding">
            {
              system[2].version.map((val, i) => {
                return <li key={i} className="liversion"><span className="version">Version :</span>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-3 btn_align1">
          {
            system[3].assign.map((val, i) => {
              return <button className=" assign" key={i} >{val}</button>;
            })
          }


        </div>
        <div className="col-md-1 btn_align2">
          {
            system[4].icon.map((val, i) => {
              return <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
            })
          }

        </div>

      </div>
    </div>);
  }
}

