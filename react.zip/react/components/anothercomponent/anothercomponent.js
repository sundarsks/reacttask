import React from 'react';
import { Cisco_1, Cisco_2, Cisco_3, Cisco_4, Cisco_5 } from '../anothercomponent/right';
import ReactDOM from 'react-dom';
import {Link} from 'react-router-dom';
var jsonvalues = require('./data.json');
class anothercomponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      "active": "",
      "elem": ""
    }

  }

  loadcomponent(evt) {
    console.log(evt.target.value)

    this.setState({
      "elem": event.target.value,
      "active": "selected"
    })


    // alert(evt.target.value);
    switch (evt.target.value) {
      case 0: ReactDOM.render(<Cisco_1 />, document.getElementById('comp'));
        break;
      // case 1: ReactDOM.render(<Cisco_2 />, document.getElementById('comp'));
      //   break;
      // case 2: ReactDOM.render(<Cisco_3 />, document.getElementById('comp'));
      //   break;
      // case 3: ReactDOM.render(<Cisco_4 />, document.getElementById('comp'));
      //   break;
      // case 4: ReactDOM.render(<Cisco_5 />, document.getElementById('comp'));
      //   break;
    }

  }
  render() {
    return (<div className="container-fluid">
      {/* <h2>login Page</h2>
      <p>{this.props.match.params.username}</p>
      <p>{valuess.name}</p> */}
      <div className="row">
        <div className="col-md-6 ">
          <img className="insidelogo" src="./../images/mainlogo.png"></img>
          <h4 className="text">DNA center</h4>
        </div>
        <div className="col-md-6">
        
          <i className="fa fa-cog setting" aria-hidden="true"></i>
          <i className="fa fa-th thead" aria-hidden="true"></i>
          <Link to="/">
        <i className="fa fa-sign-out setting" aria-hidden="true">Logout</i>
        </Link>
        </div>
      </div>
      <hr></hr>
      <div className="row">
        <div className="col-md-6 ">
          <h4 className="text">Physical</h4>
          <p className="text">|</p>
          <h4 className="text blue">Virtual</h4>
        </div>
        <div className="col-md-6">

          <i className="fa fa-exclamation-circle icon thead fa-2x" aria-hidden="true"></i>
          <p className="pipe">|</p>
          <i className="fa fa-list setting icon fa-2x" aria-hidden="true"></i>
          <p className="pipe">|</p>
          <i className="fa fa-upload thead icon fa-2x" aria-hidden="true"></i>
          <p className="pipe">|</p>
          <i className="fa fa-download setting icon fa-2x" aria-hidden="true"></i>

        </div>
      </div>
      <div className="row">
        <div className="col-md-3 bgcolor">
          <h4 className="headtext">Select Device Family</h4>

          <ul className="sidemenu">
            {
              jsonvalues[0].name.map((val, i) => {
                return <li key={i} value={i} className={(this.state.active === "selected" && this.state.elem === i) ? 'selected' : ''} onClick={this.loadcomponent.bind(this)}>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-9" id="comp">

        </div>
      </div>
    </div>);
  }
}
export default anothercomponent



