import React from 'react';
var jsonvalues= require('./data.json');
class anothercomponent extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (<div className="container-fluid">
      {/* <h2>login Page</h2>
      <p>{this.props.match.params.username}</p>
      <p>{valuess.name}</p> */}
      <div className="row">
        <div className="col-md-6 ">
          <img className="insidelogo" src="./../images/mainlogo.png"></img>
          <h4 className="text">DNA center</h4>
        </div>
        <div className="col-md-6">
          <i className="fa fa-cog setting fa-2x" aria-hidden="true"></i>
          <i className="fa fa-th thead fa-2x" aria-hidden="true"></i>
        </div>
      </div>
      <hr></hr>
      <div className="row">
        <div className="col-md-6 ">
          <h4 className="text">Physical</h4>
          <p className="text">|</p>
          <h4 className="text blue">Virtual</h4>
        </div>
        <div className="col-md-6">

          <i className="fa fa-exclamation-circle thead fa-2x" aria-hidden="true"></i>
          <p className="pipe">|</p>
          <i className="fa fa-list setting fa-2x" aria-hidden="true"></i>
          <p className="pipe">|</p>
          <i className="fa fa-upload thead fa-2x" aria-hidden="true"></i>
          <p className="pipe">|</p>
          <i className="fa fa-download setting fa-2x" aria-hidden="true"></i>

        </div>
      </div>
      <div className="row">
      <div className="col-md-3 bgcolor ">
      <h4 className="headtext">Select Device Family</h4>

      <ul>
        {
          jsonvalues[0].name.map((val,i) =>  {
            return <li key={i}>{val}</li>;
          })
        }
      </ul>
      </div>
      <div className="col-md-9">

      </div>
      </div>
    </div>);
  }
}
export default anothercomponent
