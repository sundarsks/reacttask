import React from 'react';
import ReactDOM from 'react-dom';
import history from './history';
import { Route, Switch, BrowserRouter as Router } from 'react-router-dom';
import Login from './components/loginComponent/loginComponent';
import anothercomponent from './components/anothercomponent/anothercomponent';  


const routing = (
  <Router history={history}>
    <Switch>
      <Route  exact path="/" component={Login} />
      <Route  path="/dashboard" component={anothercomponent} />
    </Switch>
  </Router>
)
ReactDOM.render(routing, document.getElementById('root'));



