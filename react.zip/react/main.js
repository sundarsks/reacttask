import React from 'react';
import ReactDOM from 'react-dom';
import { Route, Switch,Link, BrowserRouter as Router } from 'react-router-dom';
import Login from './components/loginComponent/loginComponent';
import anothercomponent from './components/anothercomponent/anothercomponent';


const routing = (
  <Router>
    <Switch>
      <Route  exact path="/" component={Login} />
      <Route path="/dashboard" component={anothercomponent} />
    </Switch>
  </Router>
)
ReactDOM.render(routing, document.getElementById('root'));



